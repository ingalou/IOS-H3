//
//  GrecGradesTableViewCell.swift
//  Ios h3
//
//  Created by Ingal Prudente Cornier on 23/11/2018.
//  Copyright © 2018 Ingal Prudente Cornier. All rights reserved.
//

import UIKit

class GrecGradesTableViewCell: UITableViewCell {

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func front(){
//        let red = UIColor(displayP3Red: 238/255, green: 101/255, blue: 101/255, alpha: 1.0)
//        let grey = UIColor(displayP3Red: 115/255, green: 115/255, blue: 115/255, alpha: 1.0)
//
//        gradeValue.textColor = red
//        gradeValue.layer.borderWidth = 1
//        gradeValue.layer.borderColor = red.cgColor
//        gradeValue.frame.size.width = gradeValue.intrinsicContentSize.width + 10
//        gradeValue.frame.size.height = gradeValue.frame.size.width
//        gradeValue.textAlignment = .center
//        gradeValue.layer.cornerRadius = gradeValue.frame.height/2
//    }

}
